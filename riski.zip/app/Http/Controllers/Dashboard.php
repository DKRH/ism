<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Yajra\Datatables\Datatables;
use App\Models\ListRapat as tbl;
use App\Models\Admin as tbl1;
use Illuminate\Support\Facades\Session;

class Dashboard extends Controller
{
    public function index(Request $request)
    {
        return view('dashboard');
    }
    public function login() {
        return view('adminlogin');
    }
    public function login_validation(Request $request) {
        $msg = [];
        if (!tbl1::where('nip', $request->nip)->where('password', $request->password)->exists()) {
            $msg['status'] = 'error';
            $msg['text'] = 'NIP/Password Salah';
            return Response()->json($msg);
        }
        $d = tbl1::where('nip', $request->nip)->where('password', $request->password)->first();
        $msg['status'] = 'sukses';
        $msg['text'] = '';
        Session::put('id', $d->id);
        Session::put('nip', $d->nip);
        Session::put('nama', $d->nama);
        return Response()->json($msg);
    }
    public function logout() {
        Session::flush();
        return redirect('/login');
    }
    public function ganti_password() {
        return view('adminganti');
    }
    public function ganti_password_simpan(Request $request) {
        $id = Session::get('id');
        $nip = Session::get('nip');
        if (!tbl1::where('nip', $nip)->where('password', $request->passwordlama)->exists()) {
            $msg['status'] = 'error';
            $msg['text'] = 'Password Lama tidak sesuai (Salah)';
            return Response()->json($msg);
        }
        if ($request->passwordbaru != $request->passwordbaru2) {
            $msg['status'] = 'error';
            $msg['text'] = 'Password Baru dan Password Baru 2 tidak sama';
            return Response()->json($msg);
        }
        tbl1::where('id', $id)
            ->update(['password' => $request->passwordbaru]);

        $msg['status'] = 'sukses';
        $msg['text'] = '';
        return Response()->json($msg);
    }
    public function profil() {
        return view('adminprofil');
    }
}

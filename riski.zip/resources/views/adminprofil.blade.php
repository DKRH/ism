
@extends('layouts/admin')

@section('content')
<div class="container-fluid">
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            Profil
        </div>
        <div class="card-body">
            
        </div>
    </div>
</div>
@endsection

@section('scripts')
@endsection